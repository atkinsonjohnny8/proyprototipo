# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models


import datetime

# Create your models here.

#class Usuariosx (AbstractUser):
#	nickname= models.CharField(max_length=30)
#	contrasena = models.CharField(max_length=30)
#	fecha_creacion_nick = models.DateTimeField(default=datetime.datetime.now)


#	def __str__(self):
#		return self.nickname