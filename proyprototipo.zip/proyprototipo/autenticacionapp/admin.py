# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin

# Register your models here.

#from . models import Usuariosx
from django.contrib.auth.admin import UserAdmin

#admin.site.register(Usuariosx, UserAdmin)