from django import forms
from appprototipo.models import Usuarios, Mensajes
from django.forms import widgets
from django.utils import timezone






class MensajesForm(forms.ModelForm):

	
	#remitente_mensaje = models.CharField(max_length=128)
	#nombre_usuario_sys_destino = forms.CharField(max_length=30)
	#cuerpo_del_mensaje = forms.CharField(max_length=256)
	#fecha_creacion_mensaje = timezone.now()

	def coger_propietario(self, request):
		
		propietario = request.session.get('selected_project_id')
	

		x = propietario	
		return x

	class Meta:
		
		model = Mensajes
		fields = [
			
			
			
			'nombre_usuario_sys_destino',
			
			'cuerpo_del_mensaje',
			'remitente_mensaje',
		
		]	


	