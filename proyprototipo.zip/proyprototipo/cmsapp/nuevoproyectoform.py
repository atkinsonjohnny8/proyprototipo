from django import forms
from appprototipo.models import Usuarios, CorreoElectronico, Proyecto
from django.forms import widgets
from django.utils import timezone



class ProyectoForm(forms.ModelForm):

	#nombre_del_proyecto = models.CharField(max_length=80)
    #descripcion_del_proyecto= models.TextField(blank=True)
    #autor = models.ForeignKey(Usuarios, on_delete=models.CASCADE)
    #estado_de_actividad = models.CharField(max_length=7, choices=status, default=True)
    #fecha_inicio_proy = models.DateField()
    #fecha_fin_proy = models.DateField()


	class Meta:
		model = Proyecto
		fields = [
			
			'nombre_del_proyecto',
			'descripcion_del_proyecto',
			'autor',
			'estado_de_actividad',
			'fecha_inicio_proy',
			'fecha_fin_proy',
		
		]	


