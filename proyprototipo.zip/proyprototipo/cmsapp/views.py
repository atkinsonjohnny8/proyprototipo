# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render




from django.shortcuts import get_object_or_404, render_to_response, redirect
#from appprototipo.formulario import UsuariosForm
from django.views.generic import CreateView, UpdateView, DeleteView, ListView, DetailView	
from django.urls import *
#from . import filters

from django.http.response import HttpResponseRedirect
from django.core.urlresolvers import reverse_lazy
#from appprototipo.filters import Filtrado, FiltradoBusqueda
from django.template import loader
from django.http import HttpResponse
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from appprototipo.serializers import usuarioSerializer
from django.http import JsonResponse
from django.template.loader import render_to_string
from django.core.serializers.json import DjangoJSONEncoder
from django.core import serializers
from django.views.generic.edit import DeletionMixin
from django.core.management.base import BaseCommand, CommandError
import json
from datetime import date, datetime
from django.utils import timezone
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required, permission_required
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
#from appprototipo.autenticador import authenticatez
from django.contrib.auth import authenticate, login
#from appprototipo.forms import LoginForm

from django.conf import settings


from django.core.cache import cache


#from appprototipo.view_login import vista_login

from django.db.models.fields import NOT_PROVIDED
import random
from django.contrib.auth.models import Group, Permission

from django.core.mail import send_mail

from appprototipo.models import Usuarios, CorreoElectronico, Mensajes, Sms, Proyecto
from appprototipo.view_login import vista_login

from cmsapp.correoform import CorreoForm 
from cmsapp.mensajesform import MensajesForm
from cmsapp.nuevoproyectoform import ProyectoForm
from cmsapp.nuevatareaform import TareaProyectoForm


from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger


def dashboard_uno(request):

	template_name = 'plantillas/cmsapp/dashboard.html'
	s = 1
	context = {'a': s}

	return render(request, template_name, context)

	#return HttpResponse("esta es la primera funcion, de prueba, del nuevo dashboard")






# //----------------------CORREOS------------------------------------------

def enviar_correo(request, template_name = 'plantillas/cmsapp/enviar_correo.html'):

	q = Usuarios.objects.all()

	data = {}
	remitente = request.session.get('selected_project_id')

	data['usuario_remitente'] = remitente

	form = CorreoForm(request.POST or None)

	if form.is_valid():
		remitente = request.POST.get('remitente', '')
		correo_destino = request.POST.get('correo_destino', '')
		subject = request.POST.get('subject', '')
		cuerpo_mensaje_correo = request.POST.get('cuerpo_mensaje_correo', '')

		


		#send_mail(subject, cuerpo_mensaje_correo, remitente, ['correo_destino'])

		form.save()

		return redirect('dashboard_uno')
	context =  {'formx': form}	

	return render(request, template_name, context)







def ver_correos_enviados_usuario_actual(request, template_name = 'plantillas/cmsapp/mostrar_correos_enviados.html'):
	#pass
	data = {}
	propietario = request.session.get('selected_project_id')

	#data['usuario_remitente'] = remitente

	#cogiendo_remitente_uno = CorreoElectronico.objects.get('remitente_id')
	#qw = CorreoElectronico.objects.all()

	qw = CorreoElectronico.objects.filter(remitente= Usuarios.objects.get(nombre_usuario_sys=propietario) )
	page = request.GET.get('page', 1)

	paginator = Paginator(qw, 3)
	try:
		paginando = paginator.page(page)
	except PageNotAnInteger:
		paginando = paginator.page(1)
	except EmptyPage:
		paginando = paginator.page(paginator.num_pages)

	data['enviados'] = paginando
	data['usuario_actual'] = propietario	
	#data['enviados'] = qw	
	return render(request, template_name, data)







def ver_correos_recibidos_usuario_actual(request, template_name = 'plantillas/cmsapp/bandeja_entrada_correos.html'):
	#pass
	data = {}
	correo_usuario_actual_listo = request.session.get('correo_usuario_actual')
	propietario = request.session.get('selected_project_id')

	#data['usuario_remitente'] = remitente

	#cogiendo_remitente_uno = CorreoElectronico.objects.get('remitente_id')
	#qw = CorreoElectronico.objects.all()
	#qw = CorreoElectronico.objects.filter(remitente= Usuarios.objects.get(nombre_usuario_sys=propietario) )



	#qw = CorreoElectronico.objects.all()
	qw = CorreoElectronico.objects.filter(correo_destino= correo_usuario_actual_listo)
	page = request.GET.get('page', 1)

	paginator = Paginator(qw, 3)
	try:
		paginando = paginator.page(page)
	except PageNotAnInteger:
		paginando = paginator.page(1)
	except EmptyPage:
		paginando = paginator.page(paginator.num_pages)

	data['correos_recibidos'] = paginando
	data['dircorreo_usuario_actual'] = correo_usuario_actual_listo	
	data['owner_del_correo'] = propietario	
	#data['enviados'] = qw	
	return render(request, template_name, data)		


# //----------------------MENSAJES------------------------------------------

def enviar_mensaje(request, template_name = 'plantillas/cmsapp/enviar_mensaje.html'):

	q = Usuarios.objects.all()

	data = {}
	
	#data['usuario_remitente'] = remitente
	propietario = request.session.get('selected_project_id')


	form = MensajesForm(request.POST or None, initial={'remitente_mensaje': propietario})

	if form.is_valid():

		#remitente_mensaje = request.session.get('selected_project_id')
		remitente_mensaje = propietario

		nombre_usuario_sys_destino = request.POST.get('nombre_usuario_sys_destino', '')
		cuerpo_del_mensaje = request.POST.get('cuerpo_del_mensaje', '')
		

		



		form.save()
	
		return redirect('dashboard_uno')
	#data['usuario_actual'] = propietario	
	context =  {'form_mensaje': form, 'usuario_actual': propietario}	

	return render(request, template_name, context)





def ver_mensajes_enviados_usuario_actual(request, template_name = 'plantillas/cmsapp/mostrar_mensajes_enviados.html'):
	#pass
	data = {}
	propietario = request.session.get('selected_project_id')

	
	#remitente_mensaje = 'kelly'	

	#cogiendo_remitente_uno = CorreoElectronico.objects.get('remitente_id')

	#qw = Mensajes.objects.all()
	#qw = Mensajes.objects.filter(remitente_mensaje = '')
	qw = Mensajes.objects.filter(remitente_mensaje = Usuarios.objects.get(nombre_usuario_sys=propietario) )

	page = request.GET.get('page', 1)

	paginator = Paginator(qw, 3)
	try:
		paginando_mensajes = paginator.page(page)
	except PageNotAnInteger:
		paginando_mensajes = paginator.page(1)
	except EmptyPage:
		paginando_mensajes = paginator.page(paginator.num_pages)


	data['mensajes_enviados'] = paginando_mensajes
	data['usuario_actual'] = propietario

	return render(request, template_name, data)	





def ver_mensajes_recibidos_usuario_actual(request, template_name = 'plantillas/cmsapp/bandeja_entrada_mensajes.html'):

	data = {}
#	mensaje_usuario_actual_listo = request.session.get('correo_usuario_actual')
	propietario = request.session.get('selected_project_id')


	
	#qw = Mensajes.objects.all()
	qw = Mensajes.objects.filter(nombre_usuario_sys_destino= Usuarios.objects.get(nombre_usuario_sys=propietario))
	page = request.GET.get('page', 1)

	paginator = Paginator(qw, 3)
	try:
		paginando = paginator.page(page)
	except PageNotAnInteger:
		paginando = paginator.page(1)
	except EmptyPage:
		paginando = paginator.page(paginator.num_pages)

	data['mensajes_recibidos'] = paginando
	data['owner_de_bandeja_mensaje'] = propietario	
	return render(request, template_name, data)	




# //----------------------MENSAJES TIPO SMS-----------------------------------------



def enviar_sms(request, template_name = 'plantillas/cmsapp/enviar_sms.html' ):
	# USAR TWILIO

	#data = {}
	#propietario = request.session.get('selected_project_id')

	#	return redirect('dashboard_uno')
	#data['usuario_actual'] = propietario	
	#context =  {'form_sms': form, 'usuario_actual': propietario}	

	#return render(request, template_name, context)
	pass


def ver_sms_enviados_usuario_actual(request, template_name = 'plantillas/cmsapp/sms_enviados.html'):
	#pass
	data = {}
	propietario = request.session.get('selected_project_id')

	#data['usuario_remitente'] = remitente

	#cogiendo_remitente_uno = CorreoElectronico.objects.get('remitente_id')
	qw = Sms.objects.all()
	#qw = Sms.objects.filter(remitente= Usuarios.objects.get(nombre_usuario_sys=propietario) )


	page = request.GET.get('page', 1)

	paginator = Paginator(qw, 3)
	try:
		paginando_sms = paginator.page(page)
	except PageNotAnInteger:
		paginando_sms = paginator.page(1)
	except EmptyPage:
		paginando_sms = paginator.page(paginator.num_pages)


	data['sms_enviados'] = paginando_sms	
	data['owner_de_bandeja_sms_enviados'] = propietario
	return render(request, template_name, data)	



# //--------------MOSTRANDO MENU SEGUN USUARIO LOGUEADO------


def mostrar_menu_segun_usuario(request, template_name = 'plantillas/cmsapp/dashboard.html'):


		data = {}
		rol_a_enviar = request.session.get('roleando')
		propietario = request.session.get('selected_project_id')

		data['rol_para_menu'] = rol_a_enviar
		data['usuario_actual'] = propietario	
		return render(request, template_name, data)




# //------------------TRABAJANDO AHORA CON EL PROJECT MANAGER------------------


def crear_proyecto(request, template_name = 'plantillas/cmsapp/crear_proyecto.html'):

	q = Usuarios.objects.all()

	data = {}
	remitente = request.session.get('selected_project_id')

	data['usuario_remitente'] = remitente

	form = ProyectoForm(request.POST or None)

	if form.is_valid():
		descripcion_del_proyecto = request.POST.get('descripcion_del_proyecto', '')
		autor = request.POST.get('autor', '')
		estado_de_actividad = request.POST.get('estado_de_actividad', '')
		fecha_inicio_proy = request.POST.get('fecha_inicio_proy', '')
		fecha_fin_proy = request.POST.get('fecha_fin_proy', '')


		#send_mail(subject, cuerpo_mensaje_correo, remitente, ['correo_destino'])

		form.save()

		return redirect('dashboard_uno')
	context =  {'formx': form}	

	return render(request, template_name, context)





def crear_tarea(request, template_name = 'plantillas/cmsapp/crear_tarea.html'):

	q = Usuarios.objects.all()

	data = {}
	remitente = request.session.get('selected_project_id')

	data['usuario_remitente'] = remitente

	form = TareaProyectoForm(request.POST or None)

	if form.is_valid():
		
		project = request.POST.get('project', '')
	    	ejecutor = request.POST.get('ejecutor', '')
	    	task_name = request.POST.get('task_name', '')
	    	status = request.POST.get('status', '')

		#send_mail(subject, cuerpo_mensaje_correo, remitente, ['correo_destino'])

		form.save()

		return redirect('dashboard_uno')
	context =  {'form_tarea': form}	

	return render(request, template_name, context)



def proy_activos(request, template_name = 'plantillas/cmsapp/proy_activosz.html'):
	data = {}
	#querz= Proyecto.objects.all()
	querz= Proyecto.objects.filter(estado_de_actividad = 2)
	data['activo'] = querz
	#return HttpResponse("listo")
	
	return render(request, template_name, data)





def proy_inactivos(request, template_name = 'plantillas/cmsapp/proy_inactivosz.html'):
	data = {}
	#querz= Proyecto.objects.all()
	querz= Proyecto.objects.filter(estado_de_actividad = 3)
	data['inactivo'] = querz
	#return HttpResponse("listo")
	
	return render(request, template_name, data)	