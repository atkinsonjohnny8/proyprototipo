from django import forms
from appprototipo.models import Usuarios, CorreoElectronico
from django.forms import widgets
from django.utils import timezone



class CorreoForm(forms.ModelForm):

	#correo = forms.EmailField(max_length = 127)
	correo_destino = forms.EmailField()
	subject = forms.CharField(max_length = 127)
	
	cuerpo_mensaje_correo = forms.CharField(widget=forms.TextInput(attrs={'class': 'special'}))
	fecha_creacion_correo = timezone.now()


	class Meta:
		model = CorreoElectronico
		fields = [
			
			'remitente',
			'correo_destino',
			'subject',
			'cuerpo_mensaje_correo',
		
		]	

