from rest_framework import serializers
from appprototipo.models import Usuarios



class usuarioSerializer(serializers.ModelSerializer):
	class Meta:
		model = Usuarios
		fields = '__all__'
		
			