
from django import forms
from appprototipo.models import Usuarios
from datetime import date, datetime
from django.forms import widgets
from django.utils import timezone
#from django_countries.widgets import CountrySelectWidget

class UsuariosForm(forms.ModelForm):
	"""docstring for UsuariosForm"""
	password = forms.CharField(widget=forms.PasswordInput)
	fecha_creacion_usuario = timezone.now()
	
	#widgets = {'country': CountrySelectWidget()}
	class Meta:
		model = Usuarios
		fields = [
			
			'nombre',
			'apellidos',
			'edad',
			'sexo',
			'profesion',
			'correo',
			'fecha_nacimiento',
			'pais',
			'ciudad_procedencia',
			'numero_celular',
			'nombre_usuario_sys',
			'rol',
			'password',
			'password',
		]
		labels = {

			'nombre': 'Nombre del usuario',
			'apellidos': 'Apellidos del usuario',
			'edad': 'Edad del usuario',
			'sexo': 'Sexo',
			'profesion': 'Profesion actual del usuario',
			'correo': 'Correo electronico',
			'fecha_nacimiento': 'Fecha de nacimiento del usuario',
			'pais': 'Pais de procedencia',
			'ciudad_procedencia': 'Ciudad de procedencia',
			'numero_celular': 'Numero de telefono movil',
			'nombre_usuario_sys': 'Nombre de usuario para autenticacion',
			'rol': 'Tipo de permiso que desea tener en el sistema',
			'password': 'Password del usuario',
			
			
		}	
		
		widgets = {
			'nombre': forms.TextInput(attrs={'class': 'form = control', 'id': 'nombre_id', 'required': True, 'placeholder': 'Escriba el nombre...'}),
			'apellidos': forms.TextInput(attrs={'class': 'form = control', 'id': 'apellidos_id','required': True, 'placeholder': 'Escriba los apellidos...'}),
			'edad': forms.TextInput(attrs={'class': 'form = control', 'id': 'edad_id','required': True, 'placeholder': 'Escriba la edad...'}),
			'sexo': forms.Select(attrs={'class': 'form = control', 'id': 'sexo_id','required': True, 'placeholder': 'Say something...'}),
			'profesion': forms.TextInput(attrs={'class': 'form = control', 'id': 'profesion_id', 'required': True, 'placeholder': 'Escriba su profesion...'}),
			'correo': forms.EmailInput(attrs={'class': 'form = control', 'id': 'correo_id','required': True, 'placeholder': 'Escriba su correo...'}),
			'fecha_nacimiento': forms.DateInput(attrs={'class': 'form = control', 'id': 'fecha_nacimiento_id','required': True, 'placeholder': 'Say something...'}),
			'pais': forms.TextInput(attrs={'class': 'form = control', 'id': 'pais_id','required': True, 'placeholder': 'Say something...'}),
			#'pais' = CountryField(blank_label='(select pais)')
			'ciudad_procedencia': forms.TextInput(attrs={'class': 'form = control', 'id': 'ciudad_procedencia_id','required': True, 'placeholder': 'Say something...'}),
			'numero_celular': forms.TextInput(attrs={'class': 'form = control', 'id': 'numero_celular_id','required': True, 'placeholder': 'Numero de celular...'}),
			'nombre_usuario_sys': forms.TextInput(attrs={'class': 'form = control', 'id': 'nombre_usuario_sys_id','required': True, 'placeholder': 'Escriba su nickname...'}),
			'rol': forms.Select(attrs={'class': 'form = control', 'id': 'rol_id','required': True, 'placeholder': 'Say something...'}),
			'password': forms.TextInput(attrs={'class': 'form = control','required': True, 'placeholder': 'Teclee su password...'}),

			# con esos id puedo usarlos en AJAX directamente, con la etiqueta #nombre_id, por ejemplo			
		}			
