# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, get_object_or_404, render_to_response, redirect, HttpResponse
from appprototipo.formulario import UsuariosForm
from django.views.generic import CreateView, UpdateView, DeleteView, ListView, DetailView, View	
from django.urls import *
#from . import filters
from appprototipo.models import Usuarios, CorreoElectronico
from django.http.response import HttpResponseRedirect
from django.core.urlresolvers import reverse_lazy
from appprototipo.filters import Filtrado, FiltradoBusqueda
from django.template import loader
from django.http import HttpResponse
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from . serializers import usuarioSerializer
from django.http import JsonResponse
from django.template.loader import render_to_string
from django.core.serializers.json import DjangoJSONEncoder
from django.core import serializers
from django.views.generic.edit import DeletionMixin
from django.core.management.base import BaseCommand, CommandError
import json
from datetime import date, datetime
from django.utils import timezone
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required, permission_required
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from appprototipo.autenticador import authenticatez
from django.contrib.auth import authenticate, login
from appprototipo.forms import LoginForm

from django.conf import settings


from django.core.cache import cache


from appprototipo.view_login import vista_login

from django.db.models.fields import NOT_PROVIDED
import random
from django.contrib.auth.models import Group, Permission



from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.forms.models import model_to_dict


import csv









def generar_grafico_edad_vs_nombre():
	pass
# instalar librerias
# incluir librerias como import etc..
# definir variables, si fuera necesario
# crear objetos pertenecientes a esas librerias, pasando parametros si fuera necesario
# llamar funciones de esa libreria y pasarle parametros (que pueden ser las variables anteriormente dichas)
# llamar o hacer consultas
# obtener resultados, renderizando ademas (si fuera necesario)


def exportar_a_pdf():
	pass

# instalar librerias
# incluir librerias como import etc..
# definir variables, si fuera necesario
# crear objetos pertenecientes a esas librerias, pasando parametros si fuera necesario
# llamar funciones de esa libreria y pasarle parametros (que pueden ser las variables anteriormente dichas)
# llamar o hacer consultas
# obtener resultados, renderizando ademas (si fuera necesario)



def geolocation_ip():
	pass

# instalar librerias
# incluir librerias como import etc..
# definir variables, si fuera necesario
# crear objetos pertenecientes a esas librerias, pasando parametros si fuera necesario
# llamar funciones de esa libreria y pasarle parametros (que pueden ser las variables anteriormente dichas)
# llamar o hacer consultas
# obtener resultados, renderizando ademas (si fuera necesario)



def canal_chat_django_channels():
	pass
	
# instalar librerias
# incluir librerias como import etc..
# definir variables, si fuera necesario
# crear objetos pertenecientes a esas librerias, pasando parametros si fuera necesario
# llamar funciones de esa libreria y pasarle parametros (que pueden ser las variables anteriormente dichas)
# llamar o hacer consultas
# obtener resultados, renderizando ademas (si fuera necesario)
















#IMPORTANDO A CSV LOS DOS PRIMEROS REGISTROS

def importando_csv(request):
	valores= Usuarios.objects.all()[:2]
	respuesta = HttpResponse(content_type='text/csv')
	respuesta['Content-Disposition'] = 'attachment; filename="listadousuarios.csv"'
	
	writer = csv.writer(respuesta)
	         

	for obj in valores:
		writer.writerow([obj.nombre, obj.apellidos, obj.correo, obj.edad])
	return respuesta
	



# FUNCION PARA HASHEAR LAS PASSWORDS

def hashear(passwordx):
	uno = 15
	dos = uno+passwordx
	return dos







#@login_required(login_url='/appprototipo/login/') USAR PERMISSION
def crearusuario(request, template_name='plantillas/usuarios_form.html'):
	
	form = UsuariosForm(request.POST or None)	
	#form=UsuariosForm(date.today())
	x = Usuarios()

	if form.is_valid():
		#hashear(form.password)
		form.save()
		return redirect('loginin')
	context =  {'form':form}	
	return render(request, template_name, context)






#ahora vemos la funcion para ver detalle de usuario 

#USAR PERMISSION
#@permission_required("permiso3") PARA LOS USUARIOS Y LOS INVITADOS ONLY
def detalleusuario(request, pk, template_name='plantillas/detalle_usuario.html'):
	detalle= get_object_or_404(Usuarios, pk=pk)
	return render(request, template_name, {'object':detalle})




# esta es la funcion de listar  y paginar hasta 3 usuarios






# RECTIFICAR ESTO PARA ENVIAR RESULTADOS DE CONSULTA COMO UN JSON
class Listadousuarios(View):
	def get(self, request):
		template_name= 'plantillas/usuarios_listar.html'
		usuarios = list(Usuarios.objects.all().values())

		data = dict()

		#itemsx = [item_serializador(item) for item in usuarios]
		#asap = json.dumps(itemsx)

		#data['resul'] = asap
		
		#context = {'lista': asap}
		
		#x = dict()
		data['lista']= usuarios
		#return JsonResponse(data)
		return render(request, template_name, data )






	


def object(self):
	self.object = object
	objectj= self.object
	return objectj


def ordenamiento(request, template_name='plantillas/usuarios_listar.html'):

	# MEZCLARLA CON USUARIOSLISTAR
	ordenar_por_nick = request.GET.get('nombre_usuario_sys')
	ordenar_por_pais = request.GET.get('pais')
	ordenar_por_cell = request.GET.get('numero_celular')
	ordenar_por_rol = request.GET.get('numero_celular')


	data = dict()

	if ordenar_por_nick:
		listar_nick = Usuarios.objects.all().order_by('nombre_usuario_sys')
		data['nick'] = listar_nick

	if ordenar_por_pais:
		listar_pais = Usuarios.objects.all().order_by('pais')
		data['countr'] = listar_pais

	if ordenar_por_cell:
		listar_cell = Usuarios.objects.all().order_by('numero_celular')	
		data['cellul'] = listar_cell
		
	if ordenar_por_rol:
		listar_rol = Usuarios.objects.all().order_by('rol')
		data['rolx'] = listar_rol
		

	return render(request, template_name, data )





def borrar_usuario(request, pk):
	user = Usuarios.objects.filter(pk__startswith = pk)
	los_que_quedan = Usuarios.objects.all()
	s = get_object_or_404(Usuarios, pk=pk)
	template_name='plantillas/usuarios_delete.html'
	data = dict()
	if request.method == 'POST':
		
		#AQUI SERIALIZAR EL QUE SE VA A BORRAR, PARA ENVIARLO A PLANTILLA
		itemsx = [item_serializador(item) for item in user]
		data = json.dumps(itemsx)

		


		user.delete()

		return redirect('/appprototipo/listarusuarios/')
		#data['listo'] = render_to_string('plantillas/partial-usuario-list.html', {'books': usuarx})
		#data['listo'] = 'algo'
		
	else:
		itemsx = [item_serializador(item) for item in user]
		asa = json.dumps(itemsx)

		usuario_de_sesion_actual = request.session.get('selected_project_id')

# ESTE data es el que en plantilla se borra por AJAX
		data['ds'] = asa
		#data['usuario_sesion'] = user
			
		return render(request,  template_name, {'usuario_sesion': s}, data) 
			#context = {'book': asa}
			#render_to_string('plantillas/usuarios_delete.html', context, request = request,)
	return HttpResponse(data, content_type='application/json')	
	#return redirect('/appprototipo/listarusuarios/') 




	
def actual_tabla_de_los_id(pk):
	# contar cantidad de registros y almacenar en variable
	cant_registros = Usuarios.objects.all().count()
	q = Usuarios.objects.all()
	qu = get_object_or_404(Usuarios, pk=5)	
	remitente_id = dict()
	
	rows = 	range(1, cant_registros+1) # esta es una lista con 12345678, en este caso
	
	# hacer un for i in cant_registros
	rowss = [rows]
	




						
		#Usuarios.objects.update(nombre = 'holax')
		
	Usuarios.objects.filter(pk = 5).update(nombre = 'hola5')

	id= {}
	for j in range(1, cant_registros+1):
			
		Usuarios.objects.filter(pk = j).update(id = j) # NO ESTA TERMINADO



		
	#pass
		#itr = iter(i)

	#Usuarios.objects.all().update(apellidos = 'Varios')

		#Usuarios.objects.filter(id = 12).update(id = 1)
		
		#chacha = Usuarios.objects.all().update(id = i)
		#chacha = CorreoElectronico.objects.filter(remitente_id = remitente_id[i])
		
		#Usuarios.objects.filter(id = 15).update(id = 1)
		
		
		#Usuarios.objects.update(nombre=i) 
					
	return HttpResponse(rows)	


#DE ESTE CODIGO COGER LO NECESARIO PARA ACTUALIZAR IDS DESPUES DE BORRAR

#from django.db import transaction
#from django.db.models import F, Max

#class History(models.Model):
 #   id = models.PositiveIntegerField(primary_key=True)       
 #   history = models.IntegerField(default=0)

 #   def save(self):
 #       with transaction.atomic():
 #           count = History.objects.count()
#
 #           objects = History.objects.all()
 #           if count > 100:
 #               objects[0].delete()
 #               if count > 1:
 #                   objects.update(id=F('id') - 1)

  #          if not self.id and count > 0:
 #               objects = objects.refresh_from_db()  # Update QuerySet
 #               self.id = objects.annotate(max_count=Max('id')).max_count + 1
 #           elif not self.id and count == 0:
 #               self.id = 1

  #          self.save()



def busqueda_y_filtrado(request):
	#ESTA BUSQUEDA HASTA AHORA SIRVE PARA ENTRARLE CON NOMBRES DE USUARIOS ONLY

	q = Usuarios.objects.all()
	template_name =  'plantillas/resultado_busqueda.html'
	

	if request.method == 'GET':

		#BP: return HttpResponse("usuario_frontend") LA PETICION = OK

		data = {}


		# LO QUE NO ESTA FUNCIONANDO ES LA SIGUIENTE LINEA
		# EL ARGUMENTO nombre_usuario_sys NO LO ESTA COGIENDO DESDE PLANTILLA

		usuario_frontend = request.GET.get('busqueda')
		#usuario_frontend = request.GET.get('nombre_usuario_sys', '')
		#return HttpResponse(usuario_frontend)

		#x = Usuarios.objects.filter(nombre_usuario_sys__iexact= usuario_frontend)
		x = Usuarios.objects.filter(nombre_usuario_sys= usuario_frontend)



		itemsx = [item_serializador(item) for item in x]
		asap = json.dumps(itemsx)

		data['resul'] = asap
		
		context = {'datos': asap}
		#return HttpResponse(asap, content_type='application/json')
		return render(request, template_name, context)


	else:
		return HttpResponse('Este nombre de usuario no existe')
		#context = q.nombre_usuario_sys
		#return render(request, 'plantillas/usuarios_listar.html', {'form_busqueda': context})

	return HttpResponse("hola")




def usuarios_update(request, pk, template_name='plantillas/actualizador_form.html'):
	usuarioactual= get_object_or_404(Usuarios, pk=pk)
	data = {}
	data['actualizando'] = usuarioactual
	form = UsuariosForm(request.POST or None, instance=usuarioactual)
	if form.is_valid():
		form.save()
		return redirect('usuarios_listar')
	return render(request, template_name, {'form':form})







#@login_required(login_url='/appprototipo/login/') USAR PERMISSION
def convertir_a_json(request, pk):
	template_name='plantillas/usuarios_delete.html'
	
	s = Usuarios.objects.all()
	context_object_name = 's'

	#data = {}

	usuario_de_sesion_actual = request.session.get('selected_project_id')

	#data['usuario_a_sacar'] = usuario_de_sesion_actual

	usuario_quiero_borrar = get_object_or_404(Usuarios, pk = pk)

	# HACER TRABAJAR EL SIGUIENTE IF:
	#if usuario_quiero_borrar == usuario_de_sesion_actual:
	#	pass # un aviso de que no se puede borrar
	#	return HttpResponse("no se puede borrar")

	#id=pk
	x=dict()
	#context_object_name = 'object'
	y = 1	
	
	items = Usuarios.objects.filter(pk__startswith = pk)
	
	if request.method == 'POST':
		itemsx = [item_serializador(item) for item in items]
		x = json.dumps(itemsx)

		return HttpResponse(x, content_type='application/json')	
	#return render_to_string(template_name, {'objectx': x}, request)	
	
	return render(request,  template_name,{'eljson': x, 'datax': usuario_quiero_borrar}) 
	
	#return HttpResponse(x, content_type='application/json')
	#return render_to_string('plantillas/usuarios_delete.html', context, request=request)


# //-----------------------------------------------------------------
# //---------------ACTUALIZANDO USANDO JSON----------------------------------------
#@login_required(login_url='/appprototipo/login/') USAR PERMISSION
def convertir_a_json_actualizar(request, pk):
	template_name='plantillas/actualizador_form.html'
	
	s = Usuarios.objects.all()
	context_object_name = 's'
	#id=pk
	x=dict()
	#context_object_name = 'object'
	y = 1	
	
	items = Usuarios.objects.filter(pk__startswith = pk)
	if request.method == 'POST':
		itemsx = [item_serializador(item) for item in items]
		x = json.dumps(itemsx)
		return HttpResponse(x, content_type='application/json')	
	#return render_to_string(template_name, {'objectx': x}, request)	
		
	return render(request,  template_name,{'eljson': x}) 



# //----------------------------------------------------------------

#@login_required(login_url='/appprototipo/login/') USAR PERMISSION
def item_serializador(item):
	return {'id': item.id, 'nombre': item.nombre, 'apellidos': item.apellidos, 'edad': item.edad, 'sexo': item.sexo, 'profesion': item.profesion, 
	'pais': item.pais, 'ciudad de procedencia': item.ciudad_procedencia, 'numero de celular': item.numero_celular, 'nick de usuario': item.nombre_usuario_sys, 'rol': item.rol, }


	#return {'id': item.id, 'nombre': item.nombre, 'pais': item.pais,}











	
	#if request.method == 'POST' and de.is_valid:
	#	q = Usuarios.objects.all()
	#	busqueda_frontend = request.POST.get('nombre_usuario_sys', '')
	#	x = q.filter(nombre_usuario_sys__iexact= busqueda_frontend)
	#	fila = get_object_or_404(x)

		
	#	data = dict()

			
		#data['listax'] = fila

		#paso como ajax a data


	#	data = json.dumps(fila)
	#	return HttpResponse(data, content_type='application/json')	
	#return render_to_string(template_name, {'objectx': x}, request)	
		
	#return render(request,  template_name,{'eljson_search': data}) 

#en la plantilla, descargo el data en sus diferentes campos en una tabla <table> usando AJAX con listax



class usuarioLista(APIView):
	
	#@login_required(login_url='/appprototipo/login/')
	def get(self, request):
		consulta = Usuarios.objects.all()
		serializ = usuarioSerializer(consulta, many = True)
		return Response(serializ.data)

	#@login_required(login_url='/appprototipo/login/')
	def post(self, request, format=None):
		serializpost = usuarioSerializer(data=request.data)
		if serializpost.is_valid():
			serializpost.save()
			return Response(serializpost.data, status=status.HTTP_201_CREATED)
		return Response(serializpost.errors, status=status.HTTP_400_BAD_REQUEST)	
		
	#@login_required(login_url='/appprototipo/login/')	
	def put(self, request, pk, format=None):
		usuarioz = self.get_object(pk)
		serializput = SnippetSerializer(usuarioz, data=request.data)
		if serializput.is_valid():
			serializput.save()
			return Response(serializput.data)
		return Response(serializput.errors, status=status.HTTP_400_BAD_REQUEST)	

	#@login_required(login_url='/appprototipo/login/')	
	def delete(self, request, pk, format=None):
		usuarioz = self.get_object(pk)
		usuarioz.delete()
		return Response(status=status.HTTP_204_NO_CONTENT)		
















#ARREGLAR ESTA FUNCION PARA QUE SUME LA EDAD DEL SELECCIONADO
#CON LA EDAD DEL USUARIO PREVIO Y MUESTRE EL RESULTADO	

#@login_required(login_url='/appprototipo/login/') USAR PERMISSION

# LA SIGUIETE FUNCION AYUDA A COMPROBAR
# INTEGRIDAD DE LA BASE DE DATOS
def suma_edad_con_previo(request, pk):
	template_name='plantillas/mostrar_suma_edad.html'
	template_name_dos='plantillas/no_existe.html'
	context_object_name='sumador'
	#edad=None

	data = {}
	valor = 1

	#este otro comentario me funciono tambien
	'''try:
		edad_usuario=Usuarios.objects.get(edad=43)
	except Usuarios.DoesNotExist:
			raise CommandError('Usuario "%s" no tiene la edad requerida' % pk)'''
	try:	
		edad_usuario= get_object_or_404(Usuarios, pk=pk)
		#actual_tabla_de_los_id(edad_usuario.pk)


	#edad_anterior= get_object_or_404(Usuarios, pk=pk)	
	#context = {'datax': edad_usuario.edad, 'otra': edad_anterior}	
	#cuando en los modelos se usa lo de __str__ en momentos como 
	#este de la view cuando yo hago consulta y pido retornar ese valor
	#para ese pk, pues el self.nombre es el que sale, y si quiero
	#otro campo tengo que decir, por ejemplo, objeto.rol y no objeto, 
	#porque si fuera objeto me saldria solo el nombre que es el que
	#se predetermino como str en los modelos

		x=(edad_usuario.pk)-1
		edad_anterior= get_object_or_404(Usuarios, pk=x)
		suma_de_edades=edad_usuario.edad+edad_anterior.edad
		hoy=date.today()
		context = {'datax': edad_usuario.edad, 
					'otra': edad_anterior.edad, 
					'suma':suma_de_edades,
					'nombre_actual': edad_usuario.nombre,
					'nombre_anterior': edad_anterior.nombre,
					'hoydia': hoy
				}
		


	#data['object_list'] = edad_usuario
	#en el caso de pasar data al conexto es simplemente 'datax': data
	#edad_previo=Usuarios.objects.filter(pk__startswith='pk')
	# VER ESTO DE LA SUMA suma_edad_con_anterior=edad_usuario+edad_previo
		return render(request, template_name, context)
	except Usuarios.DoesNotExist:
		return None
			



#PARA COGER UN USUARIO
#def get_user(self, user_id):
#	try:
#		return User.objects.get(pk=user_id)
#	except User.DoesNotExist:
#		return None


#hacer funcion o incorporar esta rutina en la creacion del usuario
#PARA CONTROL DE EXCEPCIONES Y VALIDACIONES
#instancio dos objetos con get_object
#si sdfsdf=date.today()-dato.fecha_nacimiento == edad
#return None
#else
#mostrar una excepcion en los datos que diga que 
#hoy: o la fecha_nacimiento no es la correcta o la edad esta mal





#class UsuariosActualizar(UpdateView):
#		"""docstring for UsuariosActualizar"""


#		model = Usuarios
#		form_class = UsuariosForm
#		template_name = 'plantillas/actualizador_form.html'
#		success_url=reverse_lazy ('usuarios_listar')




   






#class DetalleUsuario(DetailView):
 #   model = Usuarios
  #  template_name = 'plantillas/detalle_usuario.html'				



#def book_update(request, pk, template_name='books_fbv/book_form.html'):
 #   book= get_object_or_404(Book, pk=pk)
  #  form = BookForm(request.POST or None, instance=book)
   # if form.is_valid():
    #    form.save()
     #   return redirect('books_fbv:book_list')
    #return render(request, template_name, {'form':form})    

    #COMBINAR LAS DOS FUNCIONES ANTERIORES PARA LA
    #FUNCIONALIDAD DE ACTUALIZAR




#class UsuariosCrear(CreateView):
	
#	model = Usuarios
#	template_name = 'plantillas/usuarios_form.html'
#	form_class = UsuariosForm
#	success_url=reverse_lazy('usuarios_listar')





#class UsuariosListar(ListView):
	#	"""docstring for UsuariosListar"""
	
#		model = Usuarios
#		template_name = 'plantillas/usuarios_listar.html'
#		context_object_name = 'lista'
#		paginate_by = 3
	




# PREPARANDO PARA AJAXIFICAR CRUD (APARTE) MEDIANTE UNA API CON GETs Y POSTs





class  UsuariosList(View):
    def  get(self, request):
        listado =  list(Usuarios.objects.all().values())
        data =  dict()
        data['listado'] = listado
        return JsonResponse(data)

class  UsuariosDetail(View):
    def  get(self, request, pk):
        usuario_detalle = get_object_or_404(Usuarios, pk=pk)
        data =  dict()
        data['detalle'] = model_to_dict(usuario_detalle)
        return JsonResponse(data)

@method_decorator(csrf_exempt, name='dispatch')
class  UsuariosCreate(CreateView):
    def  post(self, request):
        data =  dict()
        form = UsuariosAjaxForm(request.POST)
        if form.is_valid():
            guardando = form.save()
            data['Usuarios'] = model_to_dict(guardando)
        else:
            data['error'] =  "form not valid!"
        return JsonResponse(data)

class  UsuariosUpdate(View):
    def  post(self, request, pk):
        data =  dict()
        actualizando = Usuarios.objects.get(pk=pk)
        form = UsuariosForm(instance=actualizando, data=request.POST)
        if form.is_valid():
            actual_guard = form.save()
            data['Usuarios'] = model_to_dict(actual_guard)
        else:
            data['error'] =  "form not valid!"
        return JsonResponse(data)

class  UsuariosDelete(View):
    def  post(self, request, pk):
        data =  dict()
        usuario_a_borrar = Usuarios.objects.get(pk=pk)
        if usuario_a_borrar:
            usuario_a_borrar.delete()
            data['message'] =  "Usuarios deleted!"
        else:
            data['message'] =  "Error!"
        return JsonResponse(data)




##def borrar_usuario(request, pk):

#   template_name='plantillas/usuarios_delete.html'º
  ##  user= get_object_or_404(Usuarios, pk=pk)    
    ##data = dict()
    ##context = {'usuario_contexto': user}
    
    ##if request.method=='POST':
    ##	data['usuarios_listar']= render_to_string('plantillas/usuarios_delete.html', context, request=request, )
        #user.delete()
		#context = {'usuario_contexto': user}
        #return redirect('usuarios_listar')
      ##  response = JsonResponse([data], encoder = DjangoJSONEncoder, safe=False)
    ##return JsonResponse(data)    
    #return render(request, template_name, {'object':user})




def borrar_usuario_ajax(request, pk):
	if request.method == 'POST':
		usuario_a_borrar = Usuarios.objects.get(pk=pk)
		usuario_a_borrar.delete()
		response_data = {}
		response_data['msg'] = 'El usuario has been deleted.'
		return HttpResponse(json.dumps(response_data), content_type="application/json")
	else:
		return HttpResponse(json.dumps({"todavia nada": "this isn't happening"}),content_type="application/json")





