from django.conf.urls import url

from . import views, view_login
from django.contrib.auth import views as auth_views
from wkhtmltopdf.views import PDFTemplateView
from cmsapp import views as views_cmsapp
from django.conf import settings


app_name = 'appprototipo '

urlpatterns = [
	url(r'^appprototipo/listarusuarios/$', views.usuarioslistar, name = "usuarios_listar"),
    #url(r'^appprototipo/listarusuarios/$', views.Listadousuarios.as_view(), name = "usuarios_listar"),
    url(r'^appprototipo/convertircsv/$', views.importando_csv, name = "convertir_csv"),

    url(r'^appprototipo/crearusuario/$', views.crearusuario, name = "usuarios_crear"),
    url(r'^appprototipo/renombrarids/$', views.actual_tabla_de_los_id, name = "renombrarids"),
    url(r'^appprototipo/eliminarsuario/(?P<pk>\d+)/$', views.borrar_usuario, name = "url_usuarios_borrar"),
    url(r'^appprototipo/actualizarusuarios/(?P<pk>\d+)/$', views.usuarios_update, name="usuarios_actualizar"),
    url(r'^appprototipo/detalleusuario/(?P<pk>\d+)/$', views.detalleusuario, name="detalle_usuario"),
    url(r'^appprototipo/filtrar/$', views.busqueda_y_filtrado, name = 'busqueda'),
    url(r'^appprototipo/restfulusuario/$', views.usuarioLista.as_view(), name="rest_ful_usuario"),
    url(r'^appprototipo/edadusuario/(?P<pk>\d+)/$', views.suma_edad_con_previo, name = "url_suma_edad"),
    url(r'^appprototipo/login/$', view_login.vista_login, name = "loginin"),
   # url(r'^appprototipo/login/$', auth_views.login, {'template_name': 'plantillas/login.html'}, name = "loginin"),

    url(r'^appprototipo/logout/$', view_login.vista_logout, name='logout'),
    #url(r'^appprototipo/logout_real/$', view_login.logout_real, name='logout_real'),
    url(r'^appprototipo/pdf/$', PDFTemplateView.as_view(template_name = 'plantillas/detalle_usuario.html', filename = 'mipdf.pdf'), name='convert_pdf'),


    url(r'^cmsapp/index/$', views_cmsapp.mostrar_menu_segun_usuario, name='dashboard_uno'),

    url(r'^cmsapp/correosend/$', views_cmsapp.enviar_correo, name='correosend'),
    url(r'^cmsapp/mensajesend/$', views_cmsapp.enviar_mensaje, name='mensajesend'),
    url(r'^cmsapp/correosenviados/$', views_cmsapp.ver_correos_enviados_usuario_actual, name='correosenviados'),
    url(r'^cmsapp/mensajesenviados/$', views_cmsapp.ver_mensajes_enviados_usuario_actual, name='mensajesenviados'),

    url(r'^cmsapp/correosrecibidos/$', views_cmsapp.ver_correos_recibidos_usuario_actual, name='correosrecibidos'),

    url(r'^cmsapp/mensajesrecibidos/$', views_cmsapp.ver_mensajes_recibidos_usuario_actual, name='mensajesrecibidos'),

    url(r'^cmsapp/enviarsms/$', views_cmsapp.enviar_sms, name='enviarsms'),
    url(r'^cmsapp/smsenviados/$', views_cmsapp.ver_sms_enviados_usuario_actual, name='sms_enviados'),

    url(r'^cmsapp/crearproyecto/$', views_cmsapp.crear_proyecto, name='crear_proyecto'),
    url(r'^cmsapp/creartarea/$', views_cmsapp.crear_tarea, name='crear_tarea'),
    url(r'^cmsapp/proyactivos/$', views_cmsapp.proy_activos, name='proy_activos'),
    url(r'^cmsapp/proyinactivos/$', views_cmsapp.proy_inactivos, name='proy_inactivos'),


    url(r'^appprototipo/listarusuariosajax/$', views.UsuariosList.as_view(), name = "usuarios_listar_ajax"),

    url(r'^appprototipo/detalleusuariosajax/(?P<pk>\d+)/$', views.UsuariosDetail.as_view(), name = "usuarios_detalle_ajax"),

    url(r'^appprototipo/crearusuariosajax/$', views.UsuariosCreate.as_view(), name = "usuarios_crear_ajax"),

    url(r'^appprototipo/updateusuariosajax/(?P<pk>\d+)/$', views.UsuariosUpdate.as_view(), name = "usuarios_update_ajax"),

    url(r'^appprototipo/deleteusuariosajax/(?P<pk>\d+)/$', views.UsuariosDelete.as_view(), name = "usuarios_delete_ajax"),





        ]  


if settings.DEBUG:
    from django.contrib.staticfiles.urls import staticfiles_urlpatterns
    urlpatterns += staticfiles_urlpatterns()

        