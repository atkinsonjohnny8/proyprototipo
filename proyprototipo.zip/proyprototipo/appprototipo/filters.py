import django_filters
from appprototipo.models import Usuarios

class Filtrado(django_filters.FilterSet):
	"""docstring for Filtrado"""
	class Meta:
		model=Usuarios
		fields=['nombre_usuario_sys', 'password']



class FiltradoBusqueda(django_filters.FilterSet):
	class Meta:
		class Meta:
			model = Usuarios
			fields = [
				
				'nombre',
				'apellidos',
				'edad',
				'sexo',
				'profesion',
				'correo',
				'fecha_nacimiento',
				'pais',
				'ciudad_procedencia',
				'numero_celular',
				'nombre_usuario_sys',
				'rol',
				'password',]
			

			