from django import forms
from appprototipo.models import Usuarios

class LoginForm(forms.Form):
	nombre_usuario_sys = forms.CharField(max_length = 30)
	password=forms.CharField(widget=forms.PasswordInput())


	class Meta:
	        model = Usuarios
	        fields = ('nombre_usuario_sys', 'password' )



