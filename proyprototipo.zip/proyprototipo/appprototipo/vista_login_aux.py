is_authenticated = False

def vista_login(request):

	
	

	if request.method == 'GET':
		context = LoginForm()
		return render (request, 'plantillas/login.html', {'form': context})

	if request.method == 'POST':
		q = Usuarios.objects.all()
	

		
#ahora se captura los datos desde el frontend FUNCIONA OK
		usuario_frontend = request.POST.get('nombre_usuario_sys', '')
		password_frontend = request.POST.get('password', '')	


# AHORA SE HACE EL FILTRADO

		x = q.filter(nombre_usuario_sys__iexact= usuario_frontend)

		# AHORA NECESITO A PARTIR DEL USUARIO FILTRADO, OBTENER SU PASSWORD
		# EN LA BD
		fila = get_object_or_404(x)
		

# con fila accedo a la contrasena del objeto x creado con get_object_...
		try:
			if x and password_frontend == fila.password:
				user = authenticatez(nombre_usuario_sys = x, password = fila.password)
				
				data = {}

				is_authenticated = True


				usuario_ready = is_authenticated

				name_user = x

				# CREAR VARIABLE CON EL NOMBRE_USUARIO_SYS EN CACHE
	# AHORA HAY QUE CREAR EN LA CACHE UNA VARIABLE DONDE SE ALMACENE fila.nombre_usuario_sys



				sw = ContentType.objects.get_for_model(Usuarios)
				# AQUI SE HACE LO DE LOS PERMISOS A LOS ROLES, CON fila.rol y un switch-case


				#INICIALIZAR UNA VARIABLE QUE TIENE ASIGNADO
				#UN ARREGLO VACIO	
				# LISTADO_PERMISOS = LISTADOP[PERM1, PERM2....] PERO VACIO

				data['listax'] = x  #aunque creo que en vez de x es fila
									# en realidad lo que va es el contexto, para
									# con listax acceder en la plantilla que indica
									# LOGIN_REDIRECT_URL	

				if fila.rol == '1':
					perm1 = Permission.objects.create(codename = 'add_group', name= 'Can add group', content_type = '')

					#		return perm1, permx o hacer un arreglo y meter los PERMISOS
					#				en ese arreglo que pertenezca a data
					return perm1
					# O RETURN LISTADO_PERMISOS = LISTADOP[PERM1, PERM2....]

				elif fila.rol == '2':
					pass
					#		perm2 = Permission.objects.create(codename = 'add_group', name= 'Can add group', content_type = '')
					#	elif fila.rol == '3':

					#		perm3 = Permission.objects.create()	

					#	elif fila.rol == '4':

					#		perm4 = Permission.objects.create()	

					# O RETURN LISTADO_PERMISOS = LISTADOP[PERM1, PERM2....]



					
				elif fila.rol == '3':
					pass


				elif fila.rol == '4':
					# ademas de los permisos usar, por ejemplo
					return redirect('/appprototipo/listarusuario/', data)





			


				# CREAR UN CONTEXTO QUE CONTENGA usuario_ready, listado_permisos[], fila y la variable de cache


				
				return redirect('/appprototipo/crearusuario/', data)

				# ESTO NO SIRVE CREO: return render(request, 'plantillas/usuarios_listar.html', {'varx': name_user})

			else:
				context = LoginForm()
				return render(request, 'plantillas/login.html', {'form': context})
		except Usuarios.DoesNotExist:	
			context = LoginForm()
			return render(request, 'plantillas/login.html', {'form': context})

