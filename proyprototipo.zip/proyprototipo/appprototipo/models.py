# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

from django.utils import timezone
from datetime import date
import datetime
from django.conf import settings
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager





class MyUserManager(BaseUserManager):
    use_in_migrations = True
    
    # python manage.py createsuperuser
    def create_superuser(self, nombre_usuario_sys, is_staff, password):
        user = self.model(
                          nombre_usuario_sys = nombre_usuario_sys,                         
                          is_staff = is_staff,
                          )
        user.set_password(password)
        user.save(using=self._db)
        return user	


class Usuarios (AbstractBaseUser):
	"""docstring for Usuarios"""
	MASCULINO = 1
	FEMENINO = 2
	SEXO=(
		(MASCULINO, 'Masculino'),
		(FEMENINO, 'Femenino'),
		)
	
	ADMINISTRADOR = 1
	USUARIO_AVANZADO = 2
	USUARIO = 3
	INVITADO = 4

	ROL=(
		(ADMINISTRADOR, 'Administradores'),
		(USUARIO_AVANZADO, 'Usuario avanzado'),
		(USUARIO, 'Usuario'),
		(INVITADO, 'Invitado'),
		)

	id = models.AutoField(primary_key=True)
	nombre = models.CharField(max_length=20)
	apellidos = models.CharField(max_length= 30)
	correo = models.EmailField(max_length= 127, unique = True, null = False, blank =False)
	edad = models.IntegerField(null = True)
	sexo = models.PositiveSmallIntegerField(choices=SEXO, blank=True, null=True)
	profesion = models.CharField(max_length=30)
	fecha_nacimiento = models.DateField(blank=True, null=True)
	pais = models.CharField(max_length=30)
	ciudad_procedencia = models.CharField(max_length=30)
	numero_celular = models.CharField(max_length=30)
	nombre_usuario_sys = models.CharField(max_length=30)
	rol= models.PositiveSmallIntegerField(choices=ROL, blank=True, null=True)
	password = models.CharField(max_length=30)
	fecha_creacion_usuario = models.DateTimeField(default=datetime.datetime.now)
	is_staff = models.NullBooleanField()
    	is_active = models.NullBooleanField(default=True)
    
    	objects = MyUserManager()


	USERNAME_FIELD = 'nombre_usuario_sys'
	REQUIRED_FIELDS = ['nombre', 'apellidos', 'correo', 'edad', 'sexo', 'profesion',
	'fecha_nacimiento', 'pais', 'ciudad_procedencia', 'numero_celular', 'rol', 'password']


	def get_absolute_url(self):
		return reverse('detalle_usuario', kwargs={'pk': self.pk})


	def check_password(self, password):
		return True
		if self.password == password:
			return True

	def __str__(self):
		return self.nombre

	



	#def save(self, * args, ** kwargs):
	#	if self.sexo == 1 or 2:
			#self.fecha_creacion_usuario == date.today()
	#		return # Yoko shall never have her own blog!
	#	else:
	#		super(Usuarios, self).save( * args, ** kwargs) # Call the "real" save() method.



class Invitaciones(models.Model):
		id = models.AutoField(primary_key=True)

		nombre_usuario_sys = models.ForeignKey(Usuarios, on_delete=models.CASCADE)
		asunto_invitacion = models.CharField(max_length=30)
		texto_invitacion = models.CharField(max_length=150)
		fecha_concretar_invitacion = models.DateTimeField()
		fecha_creacion_invitacion = models.DateTimeField()

		def __str__(self):
			return self.nombre_usuario_sys





class Publicaciones(models.Model):
	id = models.AutoField(primary_key=True)

	nombre_usuario_sys = models.ForeignKey(Usuarios, on_delete=models.CASCADE)
	asunto_publicacion = models.CharField(max_length=30)
	texto_publicacion = models.CharField(max_length=150)
	fecha_creacion_publicacion = models.DateTimeField()

	def __str__(self):
		return self.nombre_usuario_sys



class Calculos(models.Model):
	id = models.AutoField(primary_key=True)
	item = models.IntegerField()
	temperatura = models.FloatField()
	presion = models.FloatField()
	masa = models.FloatField()
	volumen = models.FloatField()
	mes = models.CharField(max_length=30)
	year = models.CharField(max_length=5)
	cantidad_de_aire = models.FloatField()
	calor_latente = models.FloatField()

	def __int__(self):
		return self.item	


class Sms(models.Model):
	id = models.AutoField(primary_key=True)
	nombre_usuario_sys = models.ForeignKey(Usuarios, on_delete=models.CASCADE)
	telefono_destino = models.CharField(max_length=30)
	cuerpo_mensaje = models.TextField()
	fecha_creacion_sms = models.DateTimeField(default=datetime.datetime.now)


class CorreoElectronico(models.Model):
	id = models.AutoField(primary_key=True)
	remitente = models.ForeignKey(Usuarios, on_delete=models.CASCADE)
	correo_destino = models.EmailField(max_length= 127, unique = True, null = False, blank =False)
	subject = models.CharField(max_length=127)
	cuerpo_mensaje_correo = models.TextField()
	fecha_creacion_correo = models.DateTimeField(default=datetime.datetime.now)



class Mensajes(models.Model):
	id = models.AutoField(primary_key=True)
	remitente_mensaje = models.CharField(max_length=128)
	nombre_usuario_sys_destino = models.ForeignKey(Usuarios, on_delete=models.CASCADE)
	cuerpo_del_mensaje = models.CharField(max_length=256)
	fecha_creacion_mensaje = models.DateTimeField(default=datetime.datetime.now)


	
class Reservaciones(models.Model):

	STATUS_CHOICES = (
		('AB1', 'Habitacion_1'),
		('AB2', 'Habitacion_2'),
		('AB3', 'Habitacion_3'),
		('AB4', 'Habitacion_4'),
		('AB5', 'Habitacion_5'),
		)
	
	fecha_reservacion = models.DateField(blank=True, null=True)
	fecha_cancelacion_reservacion = models.DateField(blank=True, null=True)
	nombre_huesped = models.CharField(max_length=255)
	codigo_habitacion = models.CharField(max_length=3, choices=STATUS_CHOICES)
	fecha_creacion_reservacion = models.DateTimeField(default=datetime.datetime.now)





# PARA UN PROJECT MANAGER, CON PROYECTOS Y TAREAS, LOS USUARIOS
# SON LOS DEL SISTEMA

status = (
    ('1', 'Pausado'),
    ('2', 'Progresando'),
    ('3', 'Finalizado'),
)



class Proyecto(models.Model):
    nombre_del_proyecto = models.CharField(max_length=80)
    descripcion_del_proyecto= models.TextField(blank=True)
    autor = models.ForeignKey(Usuarios, on_delete=models.CASCADE)
    estado_de_actividad = models.CharField(max_length=7, choices=status, default=True)
    fecha_inicio_proy = models.DateField()
    fecha_fin_proy = models.DateField()

    

    class Meta:
        ordering = ['nombre_del_proyecto']

    def __str__(self):
        return (self.nombre_del_proyecto)


class Tarea_de_Proyecto(models.Model):
    project = models.ForeignKey(Proyecto, on_delete=models.CASCADE)
    ejecutor = models.ManyToManyField(Usuarios)
    task_name = models.CharField(max_length=80)
    status = models.CharField(max_length=7, choices=status, default=1)
    


    class Meta:
        ordering = ['project', 'task_name']

    def __str__(self):
        return(self.task_name)