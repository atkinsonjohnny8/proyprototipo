
from django import forms
from appprototipo.models import Usuarios
from datetime import date, datetime
from django.forms import widgets
from django.utils import timezone






class  UsuariosAjaxForm(forms.ModelForm):

	password = forms.CharField(widget=forms.PasswordInput)
	fecha_creacion_usuario = timezone.now()
    class  Meta:
        model = Usuarios
        fields =  '__all__'