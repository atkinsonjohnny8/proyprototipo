
<script>

$(document).ready(function(){


    $("#actual").submit(function(e){
        e.preventDefault();


            $.ajax({
                url: $(this).attr('action'),
                type: $(this).attr('method'),
                data: $(this).serialize(),


                /*success: function(json){
                    console.log(json)
                    }*/

                    /*success: function(data){
            
                        $("#apellidoz").remove(data[0].apellidos);
                        $("#paiz").remove(data[0].pais);
                        $("#cell").remove(data[0].numero_celular);
                        $("#nomusuario").remove(data[0].nombre_usuario_sys);
                        $("#rolsys").remove(data[0].rol);

                    }   */

                    success: function(){
                        alert("ya funciona AJAX, solo queda efectuar actualizar");
                    }


            })

    })


})
//href="{% url 'url_usuarios_borrar' este.pk %}"


</script>